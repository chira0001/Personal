#include<stdio.h>

struct node{
	int data;
	struct node *left;
	struct node *right;
};

struct node* newNode(int num){
	struct node* temp = (struct node*) malloc(sizeof(struct node));
	temp->data = num;
	temp->left = NULL;
	temp->right = NULL;
	
	return temp;
}

void inorder(struct node* root){
	if(root != NULL){
		inorder(root->left);
		printf(" %d ",root->data);
		inorder(root->right);
	}
}

struct node* insertNode(struct node* node, int num){
	if(node == NULL){
		return newNode(num);
	}
	if(num < node->data){
		node->left = insertNode(node->left, num);
	}else if(num > node->data){
		node->right = insertNode(node->right, num);
	}
	return node;
}
int main(){
	int num;
	struct node* root = NULL;

	printf("Enter a root number : ");
	scanf("%d",&num);
	root = insertNode(root, num);
	
	while(num > 0){
		printf("Enter a number : ");
		scanf("%d",&num);
		if(num != 0){
			insertNode(root,num);
		}
	}

	printf("\nBinary Search Tree nodes in Inorder Traversal: ");
	inorder(root);
	printf("\n");
	
	return 0;
}
