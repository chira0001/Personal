#include<stdio.h>

int main(){
	int arr[8];
	int num = 32;
	int remainder = num;
	int arr_Index = 0;
	int i;
		
	do{
	//	printf("%d\n",num/2);
		printf("%d\n",remainder);		
		remainder = num /2;
		printf("%d\n",remainder);
		
	}while(remainder == 1 || remainder == 0);
	/*
	for(i = 0; i<8;i++){
		printf("%d, ",arr[i]);
	}
	
	printf("%d\n",num/2);
	printf("%d\n",num%2);
	*/
}
