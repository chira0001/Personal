import java.util.Scanner;

public class Circle{
	private double radius = 1.0;
	Scanner input = new Scanner(System.in);

	public Circle(){
		circumference = 2 * Math.PI * radius;
		System.out.println("Circumference : " + circumference);
	}
	
	public Circle(double radius){
		circumference = 2 * Math.PI * radius;
		System.out.println("Circumference : " + circumference);
	}

	public double getRadius(){
		System.out.print("Enter radius: ");
		double radius = input.nextDouble();
		setRadius(radius);
	}

	public void setRadius(double radius){
		this.radius = radius;
	}

	public double getArea(){
		double area = Math.PI * radius * radius;
	}
}