public class Cylinder extends Circle{
	private double height = 1.0;

	public Cylinder(){
		double volume = Math.PI * radius * radius * height;
		System.out.println("Volume of Cylinder = " + volume);
	}

	public Cylinder(double height){

	}

	public Cylinder(double radius, double height){

	}

	public double getHeight(){

	}

	public void setHeight(double height){

	}

	public double getVolume(){

	}
}