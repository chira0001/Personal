
public class Remuneration{
	double[] salary = {10000.00,20000.00,10000.00,15000.00,25000.00};
	double[] bonus = {10.0,5.0,15.0,20.0,10.0};

	void calcSalary(){
		//DataFormatter df = new DataFormater("0.00");

		int i;
		int sal_len = salary.length;
		int bon_len = bonus.length;
		for(i = 0; i < sal_len; i++){
			salary[i] = (salary[i] + (salary[i] * bonus[i]));
		}
	}

	void printSalary(){
		calcSalary();
		
		int j;
		int sal_len = salary.length;
		System.out.print("Salary = ");
		for(j = 0; j < sal_len; j++){
			System.out.printf("%.2f, ",salary[j]);
			if(j == sal_len - 1){
				System.out.printf("%.2f",salary[j]);
			}

		}
	}
}