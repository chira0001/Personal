

public class RemunerationDemo{
	public static void main(String[] args){
		Remuneration rem = new Remuneration();
		rem.printSalary();
	}
}