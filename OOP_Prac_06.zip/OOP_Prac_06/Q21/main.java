import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a plaintext string: ");
        String plaintext = scanner.nextLine();

        plaintext = plaintext.toUpperCase();
        
        StringBuilder ciphertext = new StringBuilder();
        for (char ch : plaintext.toCharArray()) {
            if (Character.isLetter(ch)) {
                char encryptedChar = (char) ((ch - 'A' + 3) % 26 + 'A');
                ciphertext.append(encryptedChar);
            }
        }
        
        System.out.println("The ciphertext string is: " + ciphertext.toString());

        scanner.close();
    }
}
