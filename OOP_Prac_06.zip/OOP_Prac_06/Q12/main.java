import java.util.Scanner;

public class main{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		System.out.print("Enter number: ");
		int num = input.nextInt();
		int i;
		int prod = 1;
		for(i = num; i >0; i--){
			prod = prod * i;
		}
		System.out.println("Factorial of "+num+" is "+prod);

	}
}