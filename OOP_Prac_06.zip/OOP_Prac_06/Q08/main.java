public class main{
	public static void main(String[] args){
		SumAndAverage();
	}
	
	static void SumAndAverage(){
		int i;
		int sum = 0;	
		double count = 0.0;	
		for(i = 1; i<=100; i++){
			sum = sum + i;
			count++;
		}

		double avg = sum / count; 
		System.out.println("Sum = "+ sum + " Average = " + avg);
	}
}