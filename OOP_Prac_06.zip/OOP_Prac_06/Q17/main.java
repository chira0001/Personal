

public class main{
	public static void main(String[] args){
		int i, j;
		int num = 9;
		System.out.println("* |\t1\t2\t3\t4\t5\t6\t7\t8\t9");
		System.out.println("---------------------------------------------------------------------------");
		for(i = 1; i<= num; i++){
			System.out.print(i+" |\t");
			for(j=1;j<=num;j++){
				
				System.out.print(j*i+"\t");
			}
			System.out.println();
		}
	}

}