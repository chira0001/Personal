import java.util.Scanner;

public class main{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int num = input.nextInt();
		String str_num = Integer.toString(num);
		String rev_str_num = "";
		int str_len = str_num.length();
		int i;
	
		for(i = 0; i < str_len; i++){
			rev_str_num = str_num.charAt(i) + " " +rev_str_num;
		}
		System.out.println(rev_str_num);
	}

}