import java.util.Scanner;

public class main{
	public static void main(String[] args){
		while(true){
			Scanner input = new Scanner(System.in);
			System.out.print("Enter a number: ");
			int val = input.nextInt();
			int r,j,i;
			for(r = 1; r<=val; r++){
				for(j = (val-1);j>=r;j--){
					System.out.print(" ");
				}
				for(i=1;i<=r;i++){
					System.out.print("* ");	
				}
			System.out.println();
			}
		}
		
	}
}