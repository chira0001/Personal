public class main{
	public static void main(String[] args){
		String ori_word = "racecar";
		String rev_word = "";
		int len = ori_word.length();
		int i;

		for(i = 0; i<len; i++){
			rev_word = ori_word.charAt(i) + rev_word;
		}

		if(ori_word.equals(rev_word)){
			System.out.print("Parlindrome");
		}else{
			System.out.print("Not Parlindrome");
		}
	}
	
}