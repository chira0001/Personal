import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter day (1-31): ");
        int day = scanner.nextInt();

        System.out.print("Enter month (1-12): ");
        int month = scanner.nextInt();

        System.out.print("Enter year (1900-2100): ");
        int year = scanner.nextInt();

        int totalDays = calculateTotalDays(day, month, year);
        String dayOfWeek = getDayOfWeek(totalDays);

        System.out.println("The day of the week is: " + dayOfWeek);
    }

    private static int calculateTotalDays(int day, int month, int year) {
        int baseYear = 1900;
        int days = (year - baseYear) * 365;
        
        days += (year - baseYear) / 4;

        if (isLeapYear(year) && month <= 2) {
            days -= 1;
        }

        int[] daysInMonth = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        for (int i = 1; i < month; i++) {
            days += daysInMonth[i];
        }

        days += day;

        return days;
    }

    private static boolean isLeapYear(int year) {
        return (year % 4 == 0);
    }

    private static String getDayOfWeek(int totalDays) {
        String[] daysOfWeek = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        return daysOfWeek[totalDays % 7];
    }
}
