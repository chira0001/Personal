import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int num = input.nextInt();
        //input.close();

        System.out.print("Fibonacci sequence: ");
        for (int i = 0; i < num; i++) {
            System.out.print(fibonacci(i) + (i < num - 1 ? ", " : "\n"));
        }
    }

    static int fibonacci(int n) {
        if (n == 0) return 0;
        if (n == 1) return 1;
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}
