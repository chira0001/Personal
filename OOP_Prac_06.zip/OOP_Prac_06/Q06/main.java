import java.util.Scanner;

public class main{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		
		while(true){
			System.out.print("Enter month number: ");
			int month_num = input.nextInt();
			getMonth(month_num);
		}
		
	}
	
	static void getMonth(int month){
		String[] months = {"January","February","March","April","May","June","July","August","September","October","November","December"};
		System.out.println(months[month-1]);
	}
}