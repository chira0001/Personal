import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your taxable income (in Rs): ");
        double income = scanner.nextDouble();
        
        double tax = calculateTax(income);

        System.out.printf("Your total income tax is: Rs. %.2f%n", tax);

        scanner.close();
    }

    public static double calculateTax(double income) {
        double tax = 0.0;
        double[] brackets = {600000, 600000, 600000, 600000, 600000};
        double[] rates = {0.04, 0.08, 0.12, 0.16, 0.20, 0.24};
        int i = 0;
        while (income > 0 && i < brackets.length) {
            double taxableAmount = Math.min(income, brackets[i]);
            tax += taxableAmount * rates[i];
            income -= taxableAmount;
            i++;
        }

        if (income > 0) {
            tax += income * rates[5];
        }
        return tax;
    }
}
