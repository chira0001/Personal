import java.util.Scanner;
import java.lang.*;

public class main{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		int choice;

		double length, area, radius, side1, side2, height;
		do{
			System.out.print("1. Square\n2. Circle\n3. Rectangle\n4. Cylinder\n5. Exit\n\n");
			System.out.print("Enter your choice: ");
			choice = input.nextInt();
			switch(choice){
				case 1:
					System.out.print("Enter length of a side: ");
					length = input.nextDouble();
					area = a_square(length);
					System.out.print("Area of the square : "+String.format("%.2f",area)+"\n\n");
					break;
				case 2:
					System.out.print("Enter length of the radius: ");
					radius = input.nextDouble();
					area = a_circle(radius);
					System.out.print("Area of the circle : "+String.format("%.2f",area)+"\n\n");
					break;

				case 3:
					System.out.print("Enter length of a side1: ");
					side1 = input.nextDouble();

					System.out.print("Enter length of a side2: ");
					side2 = input.nextDouble();

					area = a_rectangle(side1,side2);
					System.out.print("Area of the rectangle : "+String.format("%.2f",area)+"\n\n");
					break;

				case 4:
					System.out.print("Enter length of the radius: ");
					radius = input.nextDouble();

					System.out.print("Enter length of the height: ");
					height = input.nextDouble();

					area = a_cylinder(radius,height);
					System.out.print("Area of the cylinder : "+String.format("%.2f",area)+"\n\n");
					break;
	
				case 5:
					break;
				default:
					System.out.println("Enter a valid choice number!!!");
			}
		}while(choice != 5);	
	}

	static double a_square(double length){
		double area = length * length;
		return area;
	}
	
	static double a_circle(double radius){
		double area = (22/7.0) * radius * radius;
		return area;
	}

	static double a_rectangle(double side1, double side2){
		double area = side1 * side2;
		return area;
	}

	static double a_cylinder(double radius, double height){
		double area = 2 * (22/7.0) * radius * height;
		return area;
	}
}