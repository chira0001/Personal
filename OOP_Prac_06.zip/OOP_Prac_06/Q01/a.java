public class a{
	public static void main(String[] args){
System.out.println("\na).  -------------------\n");
		int r, i, j, k, m, n, f, t, u, w;
		for(r = 1; r<=4; r++){
			for(i=1;i<=r;i++){
				System.out.print("* ");	
			}
		System.out.println();
		}

System.out.println("\nb).  -------------------\n");

		for(r = 1; r<=4; r++){
			for(j = 4;j>=r;j--){
				System.out.print(" ");
			}
			for(i=1;i<=r;i++){
				System.out.print("* ");	
			}
		System.out.println();
		}

System.out.println("\nd).  -------------------\n");

		for(r = 1; r<=4; r++){
			for(j = 4;j>=r;j--){
				System.out.print(" ");
			}
			for(i=1;i<=r;i++){
				System.out.print("* ");	
			}
		System.out.println();
		}
		for(k=1;k<=2;k++){
			for(m = 1;m<=3;m++){
				System.out.print(" ");
			}
			for(n = 1;n<=2;n++){
				System.out.print("* ");
			}
		System.out.println();
		}

System.out.println("\nc).  -------------------\n");

		for(f=5;f>=1;f--){
			for(t=f;t>=1;t--){
				System.out.print("  ");	
			}
			for(u = 1;u<=(6-f);u++){
				System.out.print("* ");	
			}
		System.out.println();
		}
	}
}