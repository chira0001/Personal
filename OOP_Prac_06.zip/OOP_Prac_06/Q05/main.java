import java.util.Scanner;

public class main{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		System.out.print("Enter temperature: ");
		int temp = input.nextInt();
		if(temp > 30){
			System.out.print("Hot");
		}else if(temp > 20 && temp <= 30){
			System.out.print("Hot");
		}else if(temp > 10 && temp <= 20){
			System.out.print("Fine");
		}else if(temp <= 10){
			System.out.print("Cold");
		}
	}
}