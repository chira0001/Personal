public class main{
	public static void main(String[] args){
		String arr = "java";
		int len = arr.length();
		int i;
		for(i = len-1; i>=0; i--){
			System.out.print(arr.charAt(i));
		}
	}
}