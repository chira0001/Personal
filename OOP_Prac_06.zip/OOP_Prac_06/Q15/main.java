public class main{
	public static void main(String[] args){
		MultipleFinder();
	}

	static void MultipleFinder(){
		int i;
		for(i = 1; i <= 50; i++){
			if(i%3 == 0 && i%5 == 0){
				System.out.println(i+" ThreeFive");
			}else if(i%3 == 0){
				System.out.println(i+" Three");
			}else if(i%5 == 0){
				System.out.println(i+" Five");
			}else if(i%7 == 0){
				System.out.println(i+" Seven");
			}else{
				System.out.println(i);
			}
		}
	}
}