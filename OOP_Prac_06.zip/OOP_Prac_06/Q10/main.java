public class main{
	public static void main(String[] args){
		SumAndAverage();
	}
	
	static void SumAndAverage(){
		int i = 1;
		int sum = 0;	
		double count = 0.0;	
		
		do{
			sum = sum + i;
			count++;
			i++;
		}while(i <= 100);

		double avg = sum / count; 
		System.out.println("Sum = "+ sum + " Average = " + avg);
	}
}