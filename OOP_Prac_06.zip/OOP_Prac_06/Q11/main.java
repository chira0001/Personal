import java.util.Scanner;

public class main{
	public static void main(String[] args){
		int start_n,end_n;
		
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a start number: ");
		start_n = input.nextInt();

		System.out.print("Enter a end number: ");
		end_n = input.nextInt();

		Product1ToN(start_n,end_n);
	}
	static void Product1ToN(int start_n, int end_n){
		int i;
		int sum = 1;
		for(i = start_n; i <= end_n; i++){
			sum = sum * i;
		}
		System.out.println("Sum = " + sum);
	}
}