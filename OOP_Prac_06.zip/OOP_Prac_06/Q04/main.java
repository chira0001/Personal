import java.util.Arrays;
import java.util.Scanner;

public class main{
	public static void main(String[] args){

		Scanner input = new Scanner(System.in);

		System.out.print("Enter 3 values: ");
		String in = input.nextLine();

		String[] numbers=in.split(",");
		
		
		int a = Integer.parseInt(numbers[0].trim());
		int b = Integer.parseInt(numbers[1].trim());
		int c = Integer.parseInt(numbers[2].trim());
		int i;
		
		int[] arr = {a,b,c};

		Arrays.sort(arr);

		for(i = 0; i <3;i++){
			if(i == 2){
				System.out.print(arr[i]);
			}else{
				System.out.print(arr[i]+", ");
			}
		}
		
	}
}