import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a Binary string: ");
        String binaryStr = scanner.nextLine();

       Bin2Dec(binaryStr);
    }

	static void Bin2Dec(String binaryStr){
 		if (!binaryStr.matches("[01]+")) {
        	    System.out.println("error: invalid binary string \"" + binaryStr + "\"");
      		  } else {
        	    int decimalValue = Integer.parseInt(binaryStr, 2);
       		    System.out.println("The equivalent decimal number for binary \"" + binaryStr + "\" is: " + decimalValue);
       		 }
	}
}
