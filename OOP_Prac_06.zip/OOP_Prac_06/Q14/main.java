import java.util.Scanner;

public class main{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int num = input.nextInt();
		harmonic(num);
	}

	static void harmonic(int num){
		double sum = 0;
		double i;
		for(i = 1.0; i <= num; i++){
			sum = sum + (1/i);
		}
		System.out.println("Sum = "+sum);
	}

}