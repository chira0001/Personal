#include<stdio.h>
#include<stdlib.h>
#define n 5
int main(){
	int queue[n]={}, ch=1,front=-1,rear=-1,i,j=1,x=n,val=0;
	printf("Queue using Array");
	printf("\n1.Enqueue\n2.Dequeue\n3.Display\n4.Exit");
	do{
		printf("\nEnter the choice: ");
		scanf("%d",&ch);
		switch(ch){
			case 1:
				printf("Enter value: ");
				scanf("%d",&val);
				if(rear == n){
					printf("Overflow");
				}else if(rear == -1 && front == -1){
					queue[0] = val;
					rear++;
					front++;
					
				}
				else{
					//queue[(rear+1)%n]=val;
					queue[(rear+1)%n] = val;
					rear++;
				}
				break;
			case 2:
				break;
			case 3:
				for(i = 0;i<rear;i++){
					if(i == rear - 1){
						printf("%d",queue[i]);
					}else{
						printf("%d,",queue[i]);
					}
				}
				break;
			case 4:
				exit(0);
			default:
				printf("Wrong choice: please see the options");
		}
	}while(ch!=4);
}
