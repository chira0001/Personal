#include <stdio.h>
#include <stdlib.h>

#define MAX 8

int queue[MAX];
int front = -1, rear = -1;

int isEmpty() {
    return (front == -1);
}

int isFull() {
    return (rear == MAX - 1);
}

void enqueue(int element) {
    if (isFull()) {
        printf("Queue is full! Cannot insert element.\n");
        return;
    }
    if (isEmpty()) {
        front = 0;
    }
    queue[++rear] = element;
    printf("Inserted %d into queue.\n", element);
}

int dequeue() {
    if (isEmpty()) {
        printf("Queue is empty! Cannot dequeue element.\n");
        return -1;
    }
    int element = queue[front];
    if (front == rear) {
        front = rear = -1;
    } else {
        front++;
    }
    return element;
}

void display() {
    if (isEmpty()) {
        printf("Queue is empty.\n");
        return;
    }
    printf("Queue elements: ");
    for (int i = front; i <= rear; i++) {
        printf("%d ", queue[i]);
    }
    printf("\n");
}

int main() {
    int choice, element;
    
    enqueue(10);
    enqueue(20);
    enqueue(30);
    enqueue(40);
    enqueue(50);

    printf("\nInitial Queue:\n");
    display();

    printf("\nRemoving 3 elements...\n");
    dequeue();
    dequeue();
    dequeue();

    printf("\nQueue after removing 3 elements:\n");
    display();

    enqueue(60);
    enqueue(70);
    enqueue(80);
    enqueue(90);
    enqueue(100);

    printf("\nFinal Queue after inserting 5 more elements:\n");
    display();

    return 0;
}
