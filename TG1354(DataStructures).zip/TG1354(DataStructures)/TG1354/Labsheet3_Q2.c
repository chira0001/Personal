#include <stdio.h>
#include <stdlib.h>

#define MAX 5

int queue_array[MAX];
int front = -1;
int rear = -1;

int isEmpty() {
    return (front == -1);
}

int isFull() {
    return (rear == MAX - 1);
}

void enqueue(int element) {
    if (isFull()) {
        printf("Queue is full! Cannot insert element.\n");
        return;
    }
    if (isEmpty()) {
        front = 0;
    }
    queue_array[++rear] = element;
    printf("Inserted %d into queue.\n", element);
}

int dequeue() {
    if (isEmpty()) {
        printf("Queue is empty! Cannot dequeue element.\n");
        return -1;
    }
    int element = queue_array[front];
    if (front == rear) { 
        front = rear = -1;
    } else {
        front++;
    }
    return element;
}

void display() {
    if (isEmpty()) {
        printf("Queue is empty.\n");
        return;
    }
    printf("Queue elements: ");
    for (int i = front; i <= rear; i++) {
        printf("%d ", queue_array[i]);
    }
    printf("\n");
}

int peek() {
    if (isEmpty()) {
        printf("Queue is empty! No front element.\n");
        return -1;
    }
    return queue_array[front];
}

int main() {
    int option, element;
    
    while (1) {
        printf("\n1. Insert Element in Queue");
        printf("\n2. Delete Element from Queue");
        printf("\n3. Display All Elements of Queue");
        printf("\n4. Display Element at the Front position");
        printf("\n5. Exit");
        printf("\nEnter your option: ");
        
        scanf("%d", &option);

        switch (option) {
            case 1:
                printf("\nEnter Element to be Inserted: ");
                scanf("%d", &element);
                enqueue(element);
                break;

            case 2:
                element = dequeue();
                if (element != -1)
                    printf("Deleted Element from Queue: %d\n", element);
                break;

            case 3:
                display();
                break;

            case 4:
                element = peek();
                if (element != -1)
                    printf("Element at Front of Queue: %d\n", element);
                break;

            case 5:
                exit(0);

            default:
                printf("Invalid option! Please try again.\n");
        }
    }

    return 0;
}
