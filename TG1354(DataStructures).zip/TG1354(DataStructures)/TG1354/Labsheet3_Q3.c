#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 5

typedef struct
{
    int buffer_id;
    int capacity;
    int num_items;
} bufferschedule;

typedef struct
{
    bufferschedule queue[MAX_SIZE];
    int front, rear;
} bufferQueue;

void initQueue(bufferQueue *q)
{
    q->front = -1;
    q->rear = -1;
}

int isEmpty(bufferQueue *q)
{
    return (q->front == -1);
}

int isFull(bufferQueue *q)
{
    return (q->rear == MAX_SIZE - 1);
}

void enqueue(bufferQueue *q, bufferschedule buffer)
{
    if (isFull(q))
    {
        printf("Queue is full. Cannot insert buffer %d\n", buffer.buffer_id);
        return;
    }
    if (isEmpty(q))
    {
        q->front = 0;
    }
    q->queue[++q->rear] = buffer;
}

void dequeue(bufferQueue *q)
{
    if (isEmpty(q))
    {
        printf("Queue is empty. Cannot dequeue.\n");
        return;
    }
    printf("Dequeued buffer ID: %d\n", q->queue[q->front].buffer_id);
    if (q->front == q->rear)
    {
        q->front = q->rear = -1;
    }
    else
    {
        q->front++;
    }
}

void displayQueue(bufferQueue *q)
{
    if (isEmpty(q))
    {
        printf("Queue is empty.\n");
        return;
    }
    printf("Buffer Queue:\n");
    for (int i = q->front; i <= q->rear; i++)
    {
        printf("Buffer ID: %d, Capacity: %d, Items: %d\n", q->queue[i].buffer_id, q->queue[i].capacity, q->queue[i].num_items);
    }
}

void displayLastBuffer(bufferQueue *q)
{
    if (isEmpty(q))
    {
        printf("Queue is empty.\n");
        return;
    }
    bufferschedule lastBuffer = q->queue[q->rear];
    printf("Last Buffer -> ID: %d, Capacity: %d, Items: %d\n", lastBuffer.buffer_id, lastBuffer.capacity, lastBuffer.num_items);
}

int main()
{
    bufferQueue q;
    initQueue(&q);

    enqueue(&q, (bufferschedule){1, 100, 50});
    enqueue(&q, (bufferschedule){2, 200, 120});
    enqueue(&q, (bufferschedule){3, 300, 250});

    displayQueue(&q);

    displayLastBuffer(&q);

    return 0;
}
