#include <stdio.h>
int main()
{
    int arr[]={2,4,8,9};
    int arr_size = sizeof(arr)/sizeof(arr[0]);
    for(int i = arr_size - 1; i>= 0; i--){
        printf("%d\n",arr[i]);
    }
}