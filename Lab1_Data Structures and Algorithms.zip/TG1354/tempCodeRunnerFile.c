for (i = 0; i <= count; i++)
		// {
		// 	printf("%d %d\n", arr[i],count);
		// }