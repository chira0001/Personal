#include <stdio.h>
int recurse(int num);
int main()
{
	int num = 52;
	printf("Binary form %d = ",num);
	recurse(num);
}

int recurse(int num)
{
	int arr[1];
	int remainder = num;
	int i;
	int count = -1;

	if (num == 0)
	{
		return 0;
	}
	else
	{
		remainder = remainder % 2;
		num = num / 2;
		count++;
		arr[count] = remainder;
		recurse(num);
	}

	for (i = 0; i <= count; i++)
	{
		printf("%d ", arr[i]);
	}
}
