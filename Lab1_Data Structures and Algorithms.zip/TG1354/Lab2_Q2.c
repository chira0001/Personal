#include<stdio.h>
#define max 3

typedef struct{
	int top;
	int ele[max];
}stack;

void init(stack *s){
	s->top = -1;
}
int isFull(stack *s){
	if(s->top == max -1){
		return 0;
	}else{
		return -1;
	}
}
int isEmpty(stack *s){
	if(s->top == -1){
		return 0;
	}else{
		return -1;
	}
}

void push(stack *s, int item){
	if(!isFull(s)){
		printf("\nStack is full");
		return;
	}
	s->top = s->top + 1;
	s->ele[s->top] = item;
}

int pop(stack *s, int *item){
	if(!isEmpty(s)){
		printf("\nStack is empty");
		return -1;
	}
	*item = s->ele[s->top];
	s->top = s->top -1;
	return 0;
}

int main(){
	stack s;
	int item;
	init(&s);
	push(&s,10);
	push(&s,20);
	push(&s,30);
	pop(&s,&item);
	printf("\nPoped item : %d",item);
	pop(&s,&item);
	printf("\nPoped item : %d",item);
	pop(&s,&item);
	printf("\nPoped item : %d",item);
	return 0;
}
