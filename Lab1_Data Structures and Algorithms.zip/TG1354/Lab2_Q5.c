#include <stdio.h>
#include <string.h>

#define MAX 100

char stack[MAX];
int top = -1;

void push(char c) {
    if (top == MAX - 1) {
        printf("Stack overflow\n");
        return;
    }
    stack[++top] = c;
}

char pop() {
    if (top == -1) {
        printf("Stack underflow\n");
        return '\0';
    }
    return stack[top--];
}

int main() {
    char str[MAX], reversed[MAX];
    int i = 0;

    printf("Enter a string: ");
    fgets(str, MAX, stdin);

    str[strcspn(str, "\n")] = '\0';

    while (str[i] != '\0') {
        push(str[i]);
        i++;
    }

    i = 0;
    while (top != -1) {
        reversed[i++] = pop();
    }
    reversed[i] = '\0';

    printf("Reversed string: %s\n", reversed);
    return 0;
}
