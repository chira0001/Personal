import java.util.Scanner;
import java.text.DecimalFormat;

public class Main {
    public static void main(String[] args){

        Scanner obj = new Scanner(System.in);
	DecimalFormat df = new DecimalFormat("0.00");

        int choice = -1;

        while (choice != 0){
	    System.out.println("\n1. Sphere\n2. Cylinder\n3. myShape\n0. Exit\n");
            System.out.print("Please enter the number of the shape : ");
            choice = obj.nextInt();

            switch (choice){
                case 1:
                    System.out.println("You selected the Sphere");

                    System.out.print("Enter the radius of the Sphere: ");
                    double rad = obj.nextDouble();
                    Sphere mySphere = new Sphere(rad);

                    System.out.println("Surface Area : " + df.format(mySphere.calculateSphereSurfaceArea()));
                    break;
                case 2:
                    System.out.println("You selected the Cylinder");

                    System.out.print("Enter the radius of the Cylinder: ");
                    double rad2 = obj.nextDouble();

                    System.out.print("Enter the height of the Cylinder: ");
                    double h = obj.nextDouble();

                    Cylinder myCyl = new Cylinder(rad2, h);

                    System.out.println("Surface area : " + df.format(myCyl.calculateCylSurfaceArea()));

                    break;
                case 3:
                    System.out.println("You selected myShape");

                    System.out.print("Enter the radius of the Cylinder: ");
                    double rad3 = obj.nextDouble();

                    System.out.print("Enter the height of the Cylinder: ");
                    double height = obj.nextDouble();

                    MyShape my_shape = new MyShape(rad3, height);

                    System.out.println("Surface Area : " + df.format(my_shape.calculateMyShapeSurfaceArea()));
                    break;
                case 0:
                    System.out.println("Exiting.....");
                    break;
                default:
                    System.out.println("Please enter the valid integer");
                    break;
            }
        }

    }

}
