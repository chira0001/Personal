public class Cylinder {
    private static final double PI = Math.PI;
    private double radius;
    private double height;

    public Cylinder(double radius, double height){
        this.radius = radius;
        this.height = height;
    }

    public Cylinder() {
    }

    public double calculateCylSurfaceArea(){
        return (2 * PI * Math.pow(radius, 2)) + 2 * PI * radius * height;
    }
}
