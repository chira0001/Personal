public class Sphere {
    private static final double PI = Math.PI;
    private double radius;

    public Sphere(double radius){
        this.radius = radius;
    }

    public double calculateSphereSurfaceArea(){
        return 4.0 * PI * Math.pow(radius, 2);
    }
}
