public class MyShape {
    private static final double PI = Math.PI;
    private double radius;
    private double height;

    public MyShape(double radius, double height){
        this.radius = radius;
        this.height = height;
    }

    double calculateMyShapeSurfaceArea(){
        Sphere mySphere = new Sphere(radius);
        return mySphere.calculateSphereSurfaceArea() + (2 * PI * radius * height);
    }


}
