class EBook extends Book {
    public EBook(String title, String author) {
        super(title, author);
    }

    @Override
    public String getDescription() {
        return "This is a digital book.";
    }
}
