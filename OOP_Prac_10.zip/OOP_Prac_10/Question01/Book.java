class Book {
    protected String title;
    protected String author;

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
    }

    public void addBook(String title, String author) {
        System.out.println("Book added: " + title + " by " + author);
    }

    public void addBook(String title, String author, int publicationYear) {
        System.out.println("Book added: " + title + " by " + author + ", Published in " + publicationYear);
    }

    public String getDescription() {
        return "This is a book.";
    }
}
