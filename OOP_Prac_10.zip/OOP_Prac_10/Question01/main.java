public class main {
    public static void main(String[] args) {
        Book genericBook = new Book("Generic Book", "Unknown Author");
        PrintedBook printedBook = new PrintedBook("The Great Gatsby", "F. Scott Fitzgerald");
        EBook eBook = new EBook("Digital Fortress", "Dan Brown");

        genericBook.addBook("The Catcher in the Rye", "J.D. Salinger");
        genericBook.addBook("1984", "George Orwell", 1949);

        System.out.println(printedBook.getDescription());
        System.out.println(eBook.getDescription());
    }
}
