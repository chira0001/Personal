class PrintedBook extends Book {
    public PrintedBook(String title, String author) {
        super(title, author);
    }

    @Override
    public String getDescription() {
        return "This is a printed book.";
    }
}
