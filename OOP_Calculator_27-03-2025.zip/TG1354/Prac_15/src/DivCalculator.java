import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DivCalculator extends JFrame{
    private JTextField textField1;
    private JTextField textField2;
    private JButton div_btn;
    private JLabel txtInput2;
    private JPanel DivCalculator;
    private JLabel resultLabel;

    private double num1;
    private double num2;
    private double answer;

    public DivCalculator() {

    setContentPane(DivCalculator);
    setSize(350,200);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);
    setVisible(true);

        div_btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                num1 = Double.parseDouble(textField1.getText());
                num2 = Double.parseDouble(textField2.getText());
                //JOptionPane.showMessageDialog(null,"num 1 - " + num1 + " num 2 - " + num2);

                if (num2 == 0.0){
                    resultLabel.setText(String.valueOf(""));
                    JOptionPane.showMessageDialog(null,"You can't enter 0 for second number");
                }else {
                    answer = num1/num2;
                    resultLabel.setText(String.valueOf(answer));
                }
            }
        });
    }

    public static void main(String[] args) {
        new DivCalculator();
    }
}
