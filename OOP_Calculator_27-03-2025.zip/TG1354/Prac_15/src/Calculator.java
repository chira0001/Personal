import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class Calculator extends JFrame{
    private JTextArea resultDisplay;
    private JButton cButton;
    private JButton a7Button;
    private JButton a4Button;
    private JButton a1Button;
    private JButton a0Button;
    private JButton button6;
    private JButton a8Button;
    private JButton a5Button;
    private JButton a2Button;
    private JButton button10;
    private JButton button11;
    private JButton a9Button;
    private JButton a6Button;
    private JButton a3Button;
    private JButton buttonEquals;
    private JButton button16;
    private JButton button17;
    private JButton button18;
    private JButton button19;
    private JButton button20;
    private JPanel Calculator;

    private int num1;
    private int num2;
    private int num3;
    private int num4;
    private int num5;
    private int num6;
    private int num7;
    private int num8;
    private int num9;
    private int num0;

    private int result;

    private String prevText;
    private final String regex = "[+\\-*/()]";
    private final String regexInt = "[1234567890]";
    private String[] cal_array;


    public Calculator() {

        setContentPane(Calculator);
        setTitle("Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setSize(300,285);
        setVisible(true);

//        buttonEquals.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                JOptionPane.showMessageDialog(null,num1);
//            }
//        });

//##########################################################################################
        ActionListener listener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String action = e.getActionCommand();
                String[] commands_input = {"0","1","2","3","4","5","6","7","8","9"};
                Integer[] command_variable = {num0,num1,num2,num3,num4,num5,num6,num7,num8,num9};

                for(String _command : commands_input){
                   // System.out.println(_command);
                    if(action.equals(_command)){
                        if (isFirstClick()) {
                            resultDisplay.setText(_command);
                        } else {
                            prevText = resultDisplay.getText();
                            resultDisplay.setText(prevText + _command);
                        }
                    }
                }

                switch (action) {
                    case "C" :
                        resultDisplay.setText("0");
                        num1 = 0;
                        num2 = 0;
                        break;
                    case "=" :
                        JOptionPane.showMessageDialog(null, num1);
                        break;
                    case "/":
                        prevText = resultDisplay.getText();
                        resultDisplay.setText(prevText + "/");
                        break;
                    case "*":
                        prevText = resultDisplay.getText();
                        resultDisplay.setText(prevText + "*");
                        break;
                    case "-":
                        prevText = resultDisplay.getText();
                        resultDisplay.setText(prevText + "-");
                        break;
                    case "+":
                        prevText = resultDisplay.getText();
                        resultDisplay.setText(prevText + "+");
                        break;
                    case ".":
                        prevText = resultDisplay.getText();
                        resultDisplay.setText(prevText + ".");
                        break;
                    case "(":
                        prevText = resultDisplay.getText();
                        resultDisplay.setText(prevText + "(");
                        break;
                    case ")":
                        prevText = resultDisplay.getText();
                        resultDisplay.setText(prevText + ")");
                        break;
                }
            }
        };
        cButton.addActionListener(listener);
        a7Button.addActionListener(listener);
        a4Button.addActionListener(listener);
        a1Button.addActionListener(listener);
        a0Button.addActionListener(listener);
        button6.addActionListener(listener);
        a8Button.addActionListener(listener);
        a5Button.addActionListener(listener);
        a2Button.addActionListener(listener);
        button10.addActionListener(listener);
        button11.addActionListener(listener);
        a9Button.addActionListener(listener);
        a6Button.addActionListener(listener);
        a3Button.addActionListener(listener);
        button16.addActionListener(listener);
        button17.addActionListener(listener);
        button18.addActionListener(listener);
        button19.addActionListener(listener);
        button20.addActionListener(listener);


        buttonEquals.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                /*
                if(isFirstClick()){
                    resultDisplay.setText("0");
                }else{
                    prevText = resultDisplay.getText();
                    resultDisplay.setText(prevText + "=");
                }*/


                String question = resultDisplay.getText();

                String[] myArrayNumeric = question.split(regex);
                String Operator = question.replaceAll("[\\d()]", "");

                char[] operator_array = Operator.toCharArray();

                num1 = Integer.parseInt(myArrayNumeric[0]);
                num2 = Integer.parseInt(myArrayNumeric[1]);

                switch (operator_array[0]){
                    case '+':
                        result = num1 + num2;
                }




                System.out.println(num1 +operator_array[0]+ num2);
//                System.out.println(operator_array[0]);
            }
        });
    }

//#######################################################################################

public boolean isFirstClick(){
    return resultDisplay.getText().equals("0");
}

    public static void main(String[] args) {
        new Calculator();
    }
}
