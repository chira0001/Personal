import java.lang.Math;


public class Cone{
	static double pi = Math.PI;
	//public static void main(String[] args){}
    static double getConeVolume(double radius,double height){
		double volumeCone = (1/3.0) * pi * Math.pow(radius,2) * height;
		return volumeCone;
	}
}