import java.util.Scanner;
import java.lang.Math;
import java.text.DecimalFormat;

public class ShapesDemo{

	static double pi = Math.PI;

		public static void main(String[] args){
			Scanner in = new Scanner(System.in);
			DecimalFormat df = new DecimalFormat("0.00");

			Sphere sp = new Sphere();
			Cone con = new Cone();
			Myshape mShape = new Myshape();

			double radius;
			double height;
			int choice;
			do{
				System.out.print("Please enter the number of the shape\n1.Sphere\n2.Cone\n3.MyShape\n0.Exit\n\n Enter your answer : ");

				choice = in.nextInt();
				System.out.print("\n");

				switch(choice){
					case 1:
						System.out.print("Please enter value for the radius : ");
						radius = in.nextDouble();
						System.out.print("\n");
						System.out.println("Volume of the sphere is : " + df.format(sp.getSphereVolume(radius)));
						System.out.print("\n");
						break;
					case 2: 
						System.out.print("Please enter value for the radius : ");
						radius = in.nextDouble();
						System.out.print("Please enter value for the height : ");
						height = in.nextDouble();
						System.out.println("\nVolume of the cone is : " + df.format(con.getConeVolume(radius,height)));
						System.out.print("\n");
						break;
					case 3:
						System.out.print("Please enter value for the radius : ");
						radius = in.nextDouble();
						System.out.print("Please enter value for the height : ");
						height = in.nextDouble();
						System.out.println("\nVolume of the MyShape is : " + df.format(mShape.getMyShapeVolume(radius,height)));
						System.out.print("\n");
						break;
					case 0:
						System.out.println("Exiting...");
						break;
					default:
						System.out.println("Please enter valid number!!\n\n");
						
				}

			}while(choice != 0);

		}
		/*

	static double getSphereVolume(double radius){
		double volumeSphere = (4/3.0) * pi * (Math.pow(radius,3));
		return volumeSphere;
	}


	static double getConeVolume(double radius,double height){
		double volumeCone = (1/3.0) * pi * Math.pow(radius,2) * height;
		return volumeCone;
	}
	

	static double getMyShapeVolume(double radius,double height){

		double volumeMyShapeHalfSphere = (4/3.0) * pi * (Math.pow(radius,3)) / 2.0;
		double volumeMyShapeCone = (1/3.0) * pi * Math.pow(radius,2) * height;
		double myShapeVolume = volumeMyShapeHalfSphere + volumeMyShapeCone;

		//double volumeMyShape = (((4/3) * pi * Math.pow(radius,3))/2)+((1/3) * pi * Math.pow(radius,2) * height);
		//return volumeMyShape;

		return myShapeVolume;
	}
	*/
}