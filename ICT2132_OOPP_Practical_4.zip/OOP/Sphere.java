import java.lang.Math;


public class Sphere{
	static double pi = Math.PI;
	//public static void main(String[] args){}
    static double getSphereVolume(double radius){
		double volumeSphere = (4/3.0) * pi * (Math.pow(radius,3));
		return volumeSphere;
	}
}