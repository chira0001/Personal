import java.lang.Math;


public class Myshape{
	static double pi = Math.PI;
	
    static double getMyShapeVolume(double radius,double height){

		double volumeMyShapeHalfSphere = (4/3.0) * pi * (Math.pow(radius,3)) / 2.0;
		double volumeMyShapeCone = (1/3.0) * pi * Math.pow(radius,2) * height;
		double myShapeVolume = volumeMyShapeHalfSphere + volumeMyShapeCone;

		/*double volumeMyShape = (((4/3) * pi * Math.pow(radius,3))/2)+((1/3) * pi * Math.pow(radius,2) * height);
		return volumeMyShape;*/

		return myShapeVolume;
	}
}