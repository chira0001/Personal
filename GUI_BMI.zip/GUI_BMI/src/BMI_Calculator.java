import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BMI_Calculator extends JFrame{

    private JPanel BMI_Cal;
    private JTextField txt_Weight;
    private JTextField txt_Height;
    private JButton Calculate_BTN;
    private JButton cancelButton;
    private JTextArea BMI_Text_Details;

    public BMI_Calculator(){
        setContentPane(BMI_Cal);
        setTitle("BMI Calculator");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(336,366);
        setLocationRelativeTo(null);
        setVisible(true);

        //########################################################################
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        //########################################################################
        Calculate_BTN.addActionListener(new ActionListener() {
            private double weight;
            private double height;
            private double BMI;

            @Override
            public void actionPerformed(ActionEvent e) {
                this.weight = Double.parseDouble(txt_Weight.getText());
                this.height = Double.parseDouble(txt_Height.getText());

                //JOptionPane.showMessageDialog(BMI_Calculator.this, "Hello " + weight + " & "+height);
                BMIKilogram_Meter();
            }

            public void BMIKilogram_Meter(){

                this.BMI = (weight) / (height * height);
                //JOptionPane.showMessageDialog(BMI_Calculator.this, "BMI  " + BMI);
                BMI_Output();
            }
            public void BMI_Output(){
                BMI_Text_Details.append("Your BMI value : " + BMI + "\n\n");
                //System.out.println("Your BMI value : " + BMI + "\n");
                if(BMI < 18.5){
                    BMI_Text_Details.append("Condition : Underweight");
                    BMI_Condition_Output();
                } else if (BMI < 25) {
                    BMI_Text_Details.append("Condition : Normal");
                } else if (BMI < 30) {
                    BMI_Text_Details.append("Condition : Overweight");
                    BMI_Condition_Output();
                } else {
                    BMI_Text_Details.append("Condition : Obese");
                    BMI_Condition_Output();
                }

            }

            public void BMI_Condition_Output(){
                double predicted_weight_low = 18.5 * height * height;
                double predicted_weight_high = 24.9 * height * height;
                BMI_Text_Details.append("\n\nYour weight should between " + predicted_weight_low + " and " + predicted_weight_high + "\n");
            }

        });
    }

    public static void main(String[] args) {
        new BMI_Calculator();
    }
}
