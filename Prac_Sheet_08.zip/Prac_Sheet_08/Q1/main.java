import java.text.DecimalFormat;

public class main {
	

    public static void main(String[] args) {
	DecimalFormat df = new DecimalFormat("0.00");

        Cylinder c1 = new Cylinder();
        Cylinder c2 = new Cylinder(10.0);
        Cylinder c3 = new Cylinder(7.0, 10.0);


        System.out.println("Cylinder c1 -> Radius: " + c1.getRadius() + ", Height: " + c1.getHeight() +
                ", Base Area: " + df.format(c1.getArea()) + ", Volume: " + df.format(c1.getVolume()));

        System.out.println("Cylinder c2 -> Radius: " + c2.getRadius() + ", Height: " + c2.getHeight() +
                ", Base Area: " + df.format(c2.getArea()) + ", Volume: " + df.format(c2.getVolume()));

        System.out.println("Cylinder c3 -> Radius: " + c3.getRadius() + ", Height: " + c3.getHeight() +
                ", Base Area: " + df.format(c3.getArea()) + ", Volume: " + df.format(c3.getVolume()));
    }
}